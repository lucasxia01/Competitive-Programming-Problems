#include "Set.h"
#include <iostream>
#include <cassert>
using namespace std;

//void testuls()
//{
//    Set uls;
//    assert(uls.insert(20));
//    assert(uls.insert(10));
//    assert(uls.size() == 2);
//    assert(uls.contains(10));
//    ItemType x = 30;
//    assert(uls.get(0, x)  &&  x == 10);
//    assert(uls.get(1, x)  &&  x == 20);
//}

void teststr() {
    Set strs;
    assert(strs.size() == 0);
    assert(strs.insert("hi"));
    assert(strs.insert("bye"));
    assert(!strs.insert("hi"));
    assert(strs.size() == 2);
    assert(strs.erase("hi"));
    assert(strs.insert("hi"));
    Set strs2;
    assert(strs2.insert("yes"));
    strs.swap(strs2);
    assert(strs.size() == 1 && strs2.size() == 2);
    Set a;
    assert(a.empty());
    assert(a.size() == 0);
    assert(a.insert("a"));
    assert(!a.empty());
    assert(a.size() == 1);
    assert(!a.insert("a"));
    assert(!a.erase("b"));
    assert(a.erase("a"));
    assert(a.empty() && a.size() == 0);
    assert(a.insert("a") && a.insert("b") && a.insert("B") && a.insert("c"));
    assert(a.size() == 4);
    assert(a.erase("B"));
    assert(a.size() == 3);
    assert(a.contains("a") && a.contains("b") && a.contains("c"));
    string x;
    assert(a.get(0,x) && x == "a" && a.get(1,x) && x == "b" && a.get(2, x) && x== "c");
    assert(!a.get(3,x) && !a.get(-1, x) && x == "c");
    Set b;
    assert(b.insert("C") && b.insert("B") && b.size() == 2);
    a.swap(b);
    assert(a.size() == 2 && b.size() == 3);
    assert(b.contains("a") && b.contains("b") && b.contains("c"));
    assert(!b.contains("B") && !b.contains("C"));
    assert(b.get(2, x) && x == "c" && !b.get(3, x));
    assert(a.contains("C") &&  a.contains("B"));
}
int main()
{
    teststr();
    cout << "Passed all tests" << endl;
}
