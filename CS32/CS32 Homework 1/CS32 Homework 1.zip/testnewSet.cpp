//
//  testnewSet.cpp
//  CS32 Homework 1.2
//
//  Created by Lucas Xia on 1/17/19.
//  Copyright © 2019 Lucas Xia. All rights reserved.
//

#include <stdio.h>
#include <iostream>
#include <cassert>

#include "newSet.h"

int main() {
    Set a(1000);   // a can hold at most 1000 distinct items
    Set b(5);      // b can hold at most 5 distinct items
    Set c;         // c can hold at most DEFAULT_MAX_ITEMS distinct items
    Set f(-1);
    ItemType v[6] = { "A", "B", "C", "D", "E", "F"};
    c = a;
    Set d(a);
    // No failures inserting 5 distinct items into b
    for (int k = 0; k < 5; k++)
        assert(b.insert(v[k]));
    assert(b.erase("C"));
    assert(b.insert("C"));
    ItemType x;
    assert(b.get(0, x) == 1 && x == "A");
    // Failure if we try to insert a sixth distinct item into b
    assert(!b.insert(v[5]));
    assert(!b.insert("A"));
    // When two Sets' contents are swapped, their capacities are swapped
    // as well:
    std::cerr << "swap" << std::endl;
    a.swap(b);
    assert(!a.insert(v[5])  &&  b.insert(v[5]));
    d.insert("A");
    d.swap(c);
    assert(c.size() == 1 && d.size() == 0);
    a = b;
    b = c = d;
    assert(a.size() == 1 && b.size() == 0 && c.size() == 0 && d.size() == 0);
    
    std::cout << "Passed all tests" << std::endl;
    return 0;
}
